<?php

namespace App\Http\Controllers;

use App\Models\AttendanceRecord;
use App\Models\AuditLog;
use Illuminate\Http\Request;

class AttendanceWebController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        $role = $user->role->name ?? null;

        // Management roles see everyone's scans; a Healthcare Worker only
        // sees their own — same pattern as Rosters and Leave Requests.
        $canViewAll = in_array($role, ['System Administrator', 'HR Administrator', 'Supervisor / Manager']);
        $isSystemAdmin = $role === 'System Administrator';

        $query = AttendanceRecord::with(['staff', 'device']);

        $noStaffLink = false;

        if ($canViewAll) {
            if ($request->filled('date')) {
                $query->where('scan_date', $request->date);
            }
            if ($request->filled('status')) {
                $query->where('status', $request->status);
            }
        } elseif ($user->staff_id) {
            $query->where('staff_id', $user->staff_id);
        } else {
            $query->whereRaw('1 = 0');
            $noStaffLink = true;
        }

        $records = $query->orderByDesc('scan_date')->orderByDesc('scan_time')
            ->paginate(20)->withQueryString();

        return view('attendance.index', compact('records', 'canViewAll', 'isSystemAdmin', 'noStaffLink'));
    }

    /**
     * NFR-08: attendance records are immutable once committed. This mirrors
     * the API's own AttendanceRecordController::destroy() — restricted to
     * System Administrator, and logged before deletion. The route itself
     * also carries role:System Administrator middleware as a second layer.
     */
    public function destroy(Request $request, AttendanceRecord $attendanceRecord)
    {
        AuditLog::create([
            'user_id'        => $request->user()->id,
            'action'         => 'ATTENDANCE_RECORD_DELETED',
            'table_affected' => 'attendance_records',
            'record_id'      => $attendanceRecord->id,
            'ip_address'     => $request->ip(),
        ]);

        $attendanceRecord->delete();

        return redirect()->route('attendance.index')->with('status', 'Attendance record deleted and logged to the audit trail.');
    }
}
