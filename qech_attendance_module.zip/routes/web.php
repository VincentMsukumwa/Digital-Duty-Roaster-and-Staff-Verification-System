<?php

use App\Http\Controllers\AttendanceWebController;
use App\Http\Controllers\AuditLogWebController;
use App\Http\Controllers\DepartmentWebController;
use App\Http\Controllers\DeviceWebController;
use App\Http\Controllers\LeaveRequestWebController;
use App\Http\Controllers\RoleWebController;
use App\Http\Controllers\RosterWebController;
use App\Http\Controllers\SettingWebController;
use App\Http\Controllers\StaffWebController;
use App\Http\Controllers\UserWebController;
use App\Http\Controllers\WebAuthController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes — Blade UI (session-based, separate from routes/api.php)
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return redirect('/dashboard');
});

// ── Guest (not logged in) ──────────────────────────────────────────────
Route::middleware('guest')->group(function () {
    Route::get('/login', [WebAuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [WebAuthController::class, 'login']);
});

// ── Authenticated (session) ────────────────────────────────────────────
Route::middleware('auth')->group(function () {
    Route::post('/logout', [WebAuthController::class, 'logout']);

    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    // Staff & Departments — System Administrator + HR Administrator only.
    Route::middleware('role:System Administrator,HR Administrator')->group(function () {
        Route::resource('staff', StaffWebController::class)->except(['show']);
        Route::resource('departments', DepartmentWebController::class)->except(['show']);
    });

    // Rosters — anyone can view (filtered to "their own" for a Healthcare
    // Worker inside the controller); only System Administrator / Supervisor
    // can create, edit, delete, publish, or archive.
    Route::get('rosters', [RosterWebController::class, 'index'])->name('rosters.index');

    Route::middleware('role:System Administrator,Supervisor / Manager')->group(function () {
        Route::get('rosters/create', [RosterWebController::class, 'create'])->name('rosters.create');
        Route::post('rosters', [RosterWebController::class, 'store'])->name('rosters.store');
        Route::get('rosters/{roster}/edit', [RosterWebController::class, 'edit'])->name('rosters.edit');
        Route::put('rosters/{roster}', [RosterWebController::class, 'update'])->name('rosters.update');
        Route::delete('rosters/{roster}', [RosterWebController::class, 'destroy'])->name('rosters.destroy');
        Route::post('rosters/{roster}/publish', [RosterWebController::class, 'publish'])->name('rosters.publish');
        Route::post('rosters/{roster}/archive', [RosterWebController::class, 'archive'])->name('rosters.archive');
    });

    // Attendance — anyone can view (filtered to "their own" for a
    // Healthcare Worker inside the controller); deleting a record is a
    // System Administrator-only, audit-logged override (NFR-08).
    Route::get('attendance', [AttendanceWebController::class, 'index'])->name('attendance.index');

    Route::middleware('role:System Administrator')->group(function () {
        Route::delete('attendance/{attendance_record}', [AttendanceWebController::class, 'destroy'])->name('attendance.destroy');
    });

    // Leave Requests — anyone can view "their own" (or everyone's, if
    // management), and submit/cancel their own; approve/reject is
    // restricted to System Administrator / Supervisor further down.
    Route::get('leave-requests', [LeaveRequestWebController::class, 'index'])->name('leave-requests.index');
    Route::get('leave-requests/create', [LeaveRequestWebController::class, 'create'])->name('leave-requests.create');
    Route::post('leave-requests', [LeaveRequestWebController::class, 'store'])->name('leave-requests.store');
    Route::delete('leave-requests/{leaveRequest}', [LeaveRequestWebController::class, 'destroy'])->name('leave-requests.destroy');

    Route::middleware('role:System Administrator,Supervisor / Manager')->group(function () {
        Route::post('leave-requests/{leaveRequest}/approve', [LeaveRequestWebController::class, 'approve'])->name('leave-requests.approve');
        Route::post('leave-requests/{leaveRequest}/reject', [LeaveRequestWebController::class, 'reject'])->name('leave-requests.reject');
    });

    // Users, Roles, Devices, Settings, Audit Logs — System Administrator only.
    Route::middleware('role:System Administrator')->group(function () {
        Route::resource('users', UserWebController::class)->except(['show']);
        Route::resource('roles', RoleWebController::class)->except(['show']);
        Route::resource('devices', DeviceWebController::class)->except(['show']);

        Route::get('settings', [SettingWebController::class, 'index'])->name('settings.index');
        Route::get('settings/{setting}/edit', [SettingWebController::class, 'edit'])->name('settings.edit');
        Route::put('settings/{setting}', [SettingWebController::class, 'update'])->name('settings.update');

        Route::get('audit-logs', [AuditLogWebController::class, 'index'])->name('audit-logs.index');
    });
});
