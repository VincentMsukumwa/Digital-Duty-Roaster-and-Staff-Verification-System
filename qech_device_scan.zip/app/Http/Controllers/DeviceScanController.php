<?php

namespace App\Http\Controllers;

use App\Models\AttendanceRecord;
use App\Models\FingerprintTemplate;
use App\Models\Roster;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Http\Request;

/**
 * Endpoint called directly by ESP32 devices after a successful on-sensor
 * fingerprint match. Separate from AttendanceRecordController (which is
 * what the browser UI and Postman testing use) because the device sends
 * fundamentally different data: it knows its own device_id and the
 * sensor's local fingerID slot number — it does NOT know the staff_id,
 * and it has no way to know whether this is a check-in or check-out.
 * Both of those are resolved here, server-side.
 */
class DeviceScanController extends Controller
{
    public function scan(Request $request)
    {
        $data = $request->validate([
            'device_id' => 'required|exists:devices,id',
            'finger_id' => 'required|integer',
        ]);

        // Step 1: translate the sensor's local slot number into a real
        // staff_id, using the enrollment mapping recorded in
        // fingerprint_templates (finger_position holds the slot number
        // as a string, per the enrollment step below).
        $template = FingerprintTemplate::where('device_id', $data['device_id'])
            ->where('finger_position', (string) $data['finger_id'])
            ->first();

        if (! $template) {
            return response()->json([
                'result' => 'unrecognized',
                'message' => 'No staff member is enrolled at this fingerprint slot on this device.',
            ], 404);
        }

        $staffId = $template->staff_id;
        $today = now()->toDateString();
        $now = now();

        // Step 2: auto-decide check-in vs check-out — if their last scan
        // today was an "in", this one must be an "out", and vice versa.
        // No scan yet today → this is an "in".
        $lastScanToday = AttendanceRecord::where('staff_id', $staffId)
            ->where('scan_date', $today)
            ->orderByDesc('scan_time')
            ->first();

        $scanType = ($lastScanToday && $lastScanToday->scan_type === 'in') ? 'out' : 'in';

        // Step 3: compute on_time / late / early_leave, same rule as the
        // browser-facing AttendanceRecordController.
        $status = $this->computeStatus($staffId, $scanType, $today, $now->toTimeString());

        $record = AttendanceRecord::create([
            'staff_id'  => $staffId,
            'device_id' => $data['device_id'],
            'scan_type' => $scanType,
            'scan_time' => $now->toTimeString(),
            'scan_date' => $today,
            'status'    => $status,
        ]);

        return response()->json([
            'result'     => 'success',
            'staff_name' => trim($template->staff->first_name . ' ' . $template->staff->last_name),
            'scan_type'  => $scanType,
            'status'     => $status,
        ]);
    }

    /**
     * Identical logic to AttendanceRecordController::computeStatus() —
     * duplicated here deliberately rather than shared, since this
     * controller has no other reason to depend on that one, and the rule
     * is short enough that duplication is clearer than a forced coupling.
     */
    protected function computeStatus(int $staffId, string $scanType, string $scanDate, string $scanTime): string
    {
        $roster = Roster::where('staff_id', $staffId)
            ->where('status', 'published')
            ->where('effective_date', '<=', $scanDate)
            ->where(function ($q) use ($scanDate) {
                $q->whereNull('end_date')->orWhere('end_date', '>=', $scanDate);
            })
            ->first();

        if (! $roster) {
            return 'on_time';
        }

        $scan = Carbon::createFromTimeString($scanTime);

        if ($scanType === 'in') {
            $lateThreshold = (int) Setting::get('late_threshold_minutes', 15);
            $shiftStart = Carbon::createFromTimeString($roster->shift_start)->addMinutes($lateThreshold);

            return $scan->gt($shiftStart) ? 'late' : 'on_time';
        }

        $shiftEnd = Carbon::createFromTimeString($roster->shift_end);

        return $scan->lt($shiftEnd) ? 'early_leave' : 'on_time';
    }
}
