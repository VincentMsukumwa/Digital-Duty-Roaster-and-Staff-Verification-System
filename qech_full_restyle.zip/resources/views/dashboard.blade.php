@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

        <div class="bg-white rounded-2xl border border-blue-50 shadow-sm shadow-blue-100/50 p-6">
            <div class="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 font-bold mb-3">
                {{ strtoupper(substr(auth()->user()->username, 0, 1)) }}
            </div>
            <div class="text-sm text-gray-400">Signed in as</div>
            <div class="text-lg font-semibold text-gray-800">{{ auth()->user()->username }}</div>
            <span class="inline-block mt-2 text-xs font-medium bg-blue-50 text-blue-600 px-3 py-1 rounded-full">
                {{ auth()->user()->role->name ?? '—' }}
            </span>
        </div>

        <div class="bg-white rounded-2xl border border-blue-50 shadow-sm shadow-blue-100/50 p-6">
            <div class="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center text-green-600 mb-3">
                📅
            </div>
            <div class="text-sm text-gray-400">Today's date</div>
            <div class="text-lg font-semibold text-gray-800">{{ now()->format('l, d M Y') }}</div>
        </div>

        <div class="bg-white rounded-2xl border border-blue-50 shadow-sm shadow-blue-100/50 p-6">
            <div class="w-10 h-10 rounded-full bg-purple-50 flex items-center justify-center text-purple-600 mb-3">
                🏥
            </div>
            <div class="text-sm text-gray-400">System</div>
            <div class="text-lg font-semibold text-gray-800">QECH Digital Duty Roster</div>
        </div>

    </div>

    <div class="mt-8 bg-white rounded-2xl border border-blue-50 shadow-sm shadow-blue-100/50 p-8">
        <h2 class="text-md font-semibold text-gray-800 mb-2">Welcome</h2>
        <p class="text-sm text-gray-500 leading-relaxed">
            This is your dashboard. As we build out each module (Staff, Rosters, Attendance, Leave Requests),
            their pages and summary cards will appear here based on your role.
        </p>
    </div>
@endsection
