@php
    $role = auth()->user()->role->name ?? null;
@endphp

<aside class="w-64 bg-gray-900 text-gray-300 flex flex-col">
    <div class="px-6 py-6 flex items-center gap-3 border-b border-gray-800">
        <div class="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-sm">
            Q
        </div>
        <div>
            <div class="text-white font-semibold leading-tight">QECH</div>
            <div class="text-xs text-gray-500">Duty Roster &amp; Attendance</div>
        </div>
    </div>

    <nav class="flex-1 px-3 py-5 space-y-1 text-sm">

        <a href="{{ url('/dashboard') }}"
           @class([
               'flex items-center px-3 py-2.5 rounded-full transition',
               'bg-blue-600 text-white font-medium' => request()->is('dashboard'),
               'hover:bg-gray-800 hover:text-white' => ! request()->is('dashboard'),
           ])>
            Dashboard
        </a>

        {{-- Everyone can see rosters and their own attendance/leave --}}
        @if (Route::has('rosters.index'))
            <a href="{{ route('rosters.index') }}"
               @class([
                   'flex items-center px-3 py-2.5 rounded-full transition',
                   'bg-blue-600 text-white font-medium' => request()->routeIs('rosters.*'),
                   'hover:bg-gray-800 hover:text-white' => ! request()->routeIs('rosters.*'),
               ])>
                Rosters
            </a>
        @endif

        @if (Route::has('attendance.index'))
            <a href="{{ route('attendance.index') }}"
               @class([
                   'flex items-center px-3 py-2.5 rounded-full transition',
                   'bg-blue-600 text-white font-medium' => request()->routeIs('attendance.*'),
                   'hover:bg-gray-800 hover:text-white' => ! request()->routeIs('attendance.*'),
               ])>
                Attendance
            </a>
        @endif

        @if (Route::has('leave-requests.index'))
            <a href="{{ route('leave-requests.index') }}"
               @class([
                   'flex items-center px-3 py-2.5 rounded-full transition',
                   'bg-blue-600 text-white font-medium' => request()->routeIs('leave-requests.*'),
                   'hover:bg-gray-800 hover:text-white' => ! request()->routeIs('leave-requests.*'),
               ])>
                Leave Requests
            </a>
        @endif

        {{-- HR Administrator + System Administrator --}}
        @if (in_array($role, ['HR Administrator', 'System Administrator']))
            <div class="pt-5 pb-1 px-3 text-xs font-semibold uppercase tracking-wider text-blue-400/70">HR</div>

            @if (Route::has('staff.index'))
                <a href="{{ route('staff.index') }}"
                   @class([
                       'flex items-center px-3 py-2.5 rounded-full transition',
                       'bg-blue-600 text-white font-medium' => request()->routeIs('staff.*'),
                       'hover:bg-gray-800 hover:text-white' => ! request()->routeIs('staff.*'),
                   ])>
                    Staff
                </a>
            @endif

            @if (Route::has('departments.index'))
                <a href="{{ route('departments.index') }}"
                   @class([
                       'flex items-center px-3 py-2.5 rounded-full transition',
                       'bg-blue-600 text-white font-medium' => request()->routeIs('departments.*'),
                       'hover:bg-gray-800 hover:text-white' => ! request()->routeIs('departments.*'),
                   ])>
                    Departments
                </a>
            @endif

            @if (Route::has('reports-log.index'))
                <a href="{{ route('reports-log.index') }}"
                   class="flex items-center px-3 py-2.5 rounded-full hover:bg-gray-800 hover:text-white transition">
                    Reports
                </a>
            @endif
        @endif

        {{-- System Administrator only --}}
        @if ($role === 'System Administrator')
            <div class="pt-5 pb-1 px-3 text-xs font-semibold uppercase tracking-wider text-blue-400/70">Admin</div>

            @if (Route::has('users.index'))
                <a href="{{ route('users.index') }}"
                   @class([
                       'flex items-center px-3 py-2.5 rounded-full transition',
                       'bg-blue-600 text-white font-medium' => request()->routeIs('users.*'),
                       'hover:bg-gray-800 hover:text-white' => ! request()->routeIs('users.*'),
                   ])>
                    Users
                </a>
            @endif

            @if (Route::has('roles.index'))
                <a href="{{ route('roles.index') }}"
                   @class([
                       'flex items-center px-3 py-2.5 rounded-full transition',
                       'bg-blue-600 text-white font-medium' => request()->routeIs('roles.*'),
                       'hover:bg-gray-800 hover:text-white' => ! request()->routeIs('roles.*'),
                   ])>
                    Roles
                </a>
            @endif

            @if (Route::has('devices.index'))
                <a href="{{ route('devices.index') }}"
                   @class([
                       'flex items-center px-3 py-2.5 rounded-full transition',
                       'bg-blue-600 text-white font-medium' => request()->routeIs('devices.*'),
                       'hover:bg-gray-800 hover:text-white' => ! request()->routeIs('devices.*'),
                   ])>
                    Devices
                </a>
            @endif

            @if (Route::has('settings.index'))
                <a href="{{ route('settings.index') }}"
                   @class([
                       'flex items-center px-3 py-2.5 rounded-full transition',
                       'bg-blue-600 text-white font-medium' => request()->routeIs('settings.*'),
                       'hover:bg-gray-800 hover:text-white' => ! request()->routeIs('settings.*'),
                   ])>
                    Settings
                </a>
            @endif

            @if (Route::has('audit-logs.index'))
                <a href="{{ route('audit-logs.index') }}"
                   @class([
                       'flex items-center px-3 py-2.5 rounded-full transition',
                       'bg-blue-600 text-white font-medium' => request()->routeIs('audit-logs.*'),
                       'hover:bg-gray-800 hover:text-white' => ! request()->routeIs('audit-logs.*'),
                   ])>
                    Audit Logs
                </a>
            @endif
        @endif

    </nav>
</aside>
