@extends('layouts.app')

@section('title', 'Audit Logs')

@section('content')

    <div class="flex items-center justify-between mb-5">
        <form method="GET" action="{{ route('audit-logs.index') }}">
            <select name="table_affected" onchange="this.form.submit()"
                    class="border border-gray-200 rounded-xl px-4 py-2 text-sm">
                <option value="">All Tables</option>
                @foreach ($tables as $table)
                    <option value="{{ $table }}" @selected(request('table_affected') === $table)>{{ $table }}</option>
                @endforeach
            </select>
        </form>

        <span class="text-xs text-gray-400">Read-only — audit records cannot be edited or deleted (NFR-03)</span>
    </div>

    <div class="bg-white rounded-2xl border border-blue-50 shadow-sm shadow-blue-100/50 overflow-hidden">
        <table class="w-full text-sm text-left">
            <thead class="bg-gray-50 text-gray-500 uppercase text-xs">
                <tr>
                    <th class="px-4 py-3">When</th>
                    <th class="px-4 py-3">User</th>
                    <th class="px-4 py-3">Action</th>
                    <th class="px-4 py-3">Table</th>
                    <th class="px-4 py-3">Record ID</th>
                    <th class="px-4 py-3">IP Address</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                @forelse ($auditLogs as $log)
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-3 text-gray-500">{{ $log->created_at->format('d M Y H:i:s') }}</td>
                        <td class="px-4 py-3 font-medium text-gray-800">{{ $log->user->username ?? '—' }}</td>
                        <td class="px-4 py-3">
                            <span class="px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">{{ $log->action }}</span>
                        </td>
                        <td class="px-4 py-3 font-mono text-xs">{{ $log->table_affected ?? '—' }}</td>
                        <td class="px-4 py-3">{{ $log->record_id ?? '—' }}</td>
                        <td class="px-4 py-3 text-gray-500 font-mono text-xs">{{ $log->ip_address ?? '—' }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-4 py-8 text-center text-gray-400">No audit log entries yet.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $auditLogs->links() }}
    </div>

@endsection
