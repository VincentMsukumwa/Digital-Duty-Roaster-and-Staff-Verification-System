<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'QECH Attendance System')</title>

    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-b from-blue-50 via-blue-50/40 to-white text-gray-800 min-h-screen">

    <div class="flex min-h-screen">

        {{-- Sidebar --}}
        @include('partials.nav')

        {{-- Main content area --}}
        <div class="flex-1 flex flex-col">

            {{-- Top bar --}}
            <header class="bg-white/80 backdrop-blur border-b border-blue-100 px-8 py-4 flex items-center justify-between sticky top-0 z-10">
                <h1 class="text-lg font-semibold text-gray-800">@yield('title', 'Dashboard')</h1>

                <div class="flex items-center gap-3">
                    <div class="flex items-center gap-2 bg-blue-50 border border-blue-100 pl-3 pr-1 py-1 rounded-full">
                        <span class="text-sm text-gray-600">{{ auth()->user()->username ?? '' }}</span>
                        <span class="text-xs font-medium bg-blue-600 text-white px-3 py-1 rounded-full">
                            {{ auth()->user()->role->name ?? '' }}
                        </span>
                    </div>
                    <form method="POST" action="{{ url('/logout') }}">
                        @csrf
                        <button type="submit"
                                class="text-sm text-gray-500 hover:text-red-600 border border-gray-200 hover:border-red-200 px-4 py-1.5 rounded-full transition">
                            Logout
                        </button>
                    </form>
                </div>
            </header>

            {{-- Flash messages --}}
            <div class="px-8 pt-6">
                @if (session('status'))
                    <div class="bg-blue-50 border border-blue-100 text-blue-700 px-4 py-3 rounded-xl mb-2 text-sm">
                        {{ session('status') }}
                    </div>
                @endif
            </div>

            {{-- Page content --}}
            <main class="flex-1 p-8">
                @yield('content')
            </main>

        </div>
    </div>

</body>
</html>
