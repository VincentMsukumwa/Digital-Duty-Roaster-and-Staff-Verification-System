@extends('layouts.app')

@section('title', 'Staff')

@section('content')

    <div class="flex items-center justify-between mb-5">
        <form method="GET" action="{{ route('staff.index') }}" class="flex items-center gap-3">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Search name or staff no..."
                   class="border border-gray-200 rounded-xl px-4 py-2 text-sm w-64 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">

            <select name="department_id" onchange="this.form.submit()"
                    class="border border-gray-200 rounded-xl px-4 py-2 text-sm">
                <option value="">All Departments</option>
                @foreach ($departments as $department)
                    <option value="{{ $department->id }}" @selected(request('department_id') == $department->id)>
                        {{ $department->name }}
                    </option>
                @endforeach
            </select>

            <select name="status" onchange="this.form.submit()"
                    class="border border-gray-200 rounded-xl px-4 py-2 text-sm">
                <option value="">All Statuses</option>
                @foreach (['active', 'inactive', 'suspended'] as $option)
                    <option value="{{ $option }}" @selected(request('status') === $option)>{{ ucfirst($option) }}</option>
                @endforeach
            </select>

            <button type="submit" class="text-sm text-blue-600 hover:underline">Filter</button>
        </form>

        <a href="{{ route('staff.create') }}"
           class="bg-blue-600 text-white text-sm font-semibold px-5 py-2.5 rounded-full hover:bg-blue-700 transition">
            + Add Staff
        </a>
    </div>

    @if (session('status'))
        <div class="bg-green-50 border border-green-100 text-green-700 px-4 py-3 rounded-xl mb-4 text-sm">
            {{ session('status') }}
        </div>
    @endif

    <div class="bg-white rounded-2xl border border-blue-50 shadow-sm shadow-blue-100/50 overflow-hidden">
        <table class="w-full text-sm text-left">
            <thead class="bg-gray-50 text-gray-500 uppercase text-xs">
                <tr>
                    <th class="px-4 py-3">Staff No</th>
                    <th class="px-4 py-3">Name</th>
                    <th class="px-4 py-3">Department</th>
                    <th class="px-4 py-3">Position</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">
                @forelse ($staff as $member)
                    <tr class="hover:bg-blue-50/40">
                        <td class="px-4 py-3">{{ $member->staff_no }}</td>
                        <td class="px-4 py-3 font-medium text-gray-800">{{ $member->first_name }} {{ $member->last_name }}</td>
                        <td class="px-4 py-3">{{ $member->department->name ?? '—' }}</td>
                        <td class="px-4 py-3">{{ $member->position ?? '—' }}</td>
                        <td class="px-4 py-3">
                            <span @class([
                                'px-3 py-1 rounded-full text-xs font-medium',
                                'bg-green-100 text-green-700' => $member->status === 'active',
                                'bg-gray-100 text-gray-600' => $member->status === 'inactive',
                                'bg-red-100 text-red-700' => $member->status === 'suspended',
                            ])>
                                {{ ucfirst($member->status) }}
                            </span>
                        </td>
                        <td class="px-4 py-3 text-right space-x-3">
                            <a href="{{ route('staff.edit', $member) }}" class="text-blue-600 hover:underline">Edit</a>
                            <form method="POST" action="{{ route('staff.destroy', $member) }}" class="inline"
                                  onsubmit="return confirm('Delete {{ $member->first_name }} {{ $member->last_name }}? This cannot be undone.');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-600 hover:underline">Delete</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="px-4 py-8 text-center text-gray-400">No staff members found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $staff->links() }}
    </div>

@endsection
