<?php

namespace App\Http\Controllers;

use App\Models\Role;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;

class RoleWebController extends Controller
{
    public function index()
    {
        $roles = Role::withCount('users')->orderBy('name')->paginate(15);

        return view('roles.index', compact('roles'));
    }

    public function create()
    {
        return view('roles.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'        => 'required|string|max:50|unique:roles,name',
            'description' => 'nullable|string',
        ]);

        Role::create($data);

        return redirect()->route('roles.index')->with('status', 'Role added.');
    }

    public function edit(Role $role)
    {
        return view('roles.edit', compact('role'));
    }

    public function update(Request $request, Role $role)
    {
        $data = $request->validate([
            'name'        => 'required|string|max:50|unique:roles,name,' . $role->id,
            'description' => 'nullable|string',
        ]);

        $role->update($data);

        return redirect()->route('roles.index')->with('status', 'Role updated.');
    }

    public function destroy(Role $role)
    {
        // The database itself enforces ON DELETE RESTRICT on users.role_id —
        // deleting a role still assigned to any user account throws a
        // foreign key violation. We catch it here and turn it into a
        // readable message instead of a raw SQL error page.
        try {
            $role->delete();
        } catch (QueryException $e) {
            return redirect()->route('roles.index')->with('status',
                'Cannot delete this role — one or more users are still assigned to it. Reassign them first.'
            );
        }

        return redirect()->route('roles.index')->with('status', 'Role deleted.');
    }
}
