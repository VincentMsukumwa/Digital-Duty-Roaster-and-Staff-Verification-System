@extends('layouts.app')

@section('title', 'Add Device')

@section('content')
    <div class="bg-white rounded-lg shadow p-6 max-w-2xl">
        @php($device = null)

        @if ($errors->any())
            <div class="bg-red-100 text-red-700 text-sm px-4 py-2 rounded mb-4">
                <ul class="list-disc list-inside">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('devices.store') }}">
            @include('devices._form')
        </form>
    </div>
@endsection
